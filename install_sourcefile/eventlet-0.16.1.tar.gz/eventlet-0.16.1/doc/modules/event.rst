:mod:`event` -- Cross-greenthread primitive
==================================================

.. automodule:: eventlet.event
	:members:
